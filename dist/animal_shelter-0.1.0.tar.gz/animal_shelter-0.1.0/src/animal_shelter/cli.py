import logging
from pathlib import Path

import pandas as pd
import typer

from animal_shelter.data import load_data

app = typer.Typer()


@app.callback()
def main() -> None:
    """Determine animal shelter outcomes."""
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)-15s] %(name)s - %(levelname)s - %(message)s",
    )


@app.command()
def train(input_path: Path, model_path: Path) -> None:
    """Trains a model on the given dataset."""

    typer.echo(f"Loading {input_path}")

    logger = logging.getLogger(__name__)

    logger.info("Loading input dataset from %s", input_path)
    train_dataset = load_data(input_path)
    logger.info("Found %i rows", len(train_dataset))

    # TODO: Fill in your solution.
    # - Separate feature matrix X from target y

    # - add/remove features such that the feature matrix X is suitable for ML

    # - Fit a model

    # - Log the final score

    # - Save model

    logger.info(f"Wrote model to {model_path}")
